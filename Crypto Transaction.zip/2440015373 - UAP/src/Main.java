import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.text.StyledEditorKit.ForegroundAction;

public class Main {

	Scanner scan = new Scanner(System.in);
	Connect con = Connect.getConnection();
	Vector<Item> items = new Vector<>();
	Vector<Package> packages = new Vector<>();
	
	public Main() {
		menu();
	}

	public void menu() {
		loadData();
		
		int input = 0;
		
		do {
			System.out.println("Welcome to J&T Express");
			System.out.println();
			System.out.println("======================");
			System.out.println("1. Create Delivery");
			System.out.println("2. View Delivery");
			System.out.println("3. Delete Delivery");
			System.out.println("4. Exit");
			System.out.println();
			System.out.print(">> ");
			input = scan.nextInt();
			scan.nextLine();
			
			switch (input) {
			case 1:
				createDelivery();
				break;
			case 2:
				if(packages.isEmpty()) {
					System.out.println("There's No Transaction");
				}
				else viewDelivery();
				System.out.print("Wanna go back ? [press enter]");
				scan.nextLine();
				menu();
				break;
			case 3:
				if(packages.isEmpty()) {
					System.out.println("There's No Transaction");
					System.out.println();
					System.out.print("Wanna go back ? [press enter]");
					scan.nextLine();
					menu();
				}
				else deleteDelivery();
				break;
			default:
				break;
			}
		} while (input != 4);
	}
	
	public void loadData() {
		loadPackage();
		loadElectronicItem();
		loadNonElectronicItem();
	}
	
	public void loadPackage() {
		packages.clear();
		
		String packageID;
		String itemID;
		String recipientName;
		String recipientAddress;
		String userEmail;
		
		String query = "SELECT * FROM package";
		ResultSet rs = con.executeQuery(query);
		
		try {
			while(rs.next()) {
				packageID = rs.getString(1);
				itemID = rs.getString(2);
				recipientName = rs.getString(3);
				recipientAddress = rs.getString(4);
				userEmail = rs.getString(5);
				packages.add(new Package(packageID, itemID, recipientName, recipientAddress, userEmail));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void loadElectronicItem() {
		items.clear();
		
		String itemID;
		String itemName;
		int weight;
		int warranty;
		
		String query = "SELECT * FROM electronicitem";
		ResultSet rs = con.executeQuery(query);
		
		try {
			while(rs.next()) {
				itemID = rs.getString(1);
				itemName= rs.getString(2);
				weight = rs.getInt(3);
				warranty = rs.getInt(4);
				items.add(new ElectronicItem(itemID, itemName, weight, warranty));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void loadNonElectronicItem() {
		String itemID;
		String itemName;
		int weight;
		int fragile;
		
		String query = "SELECT * FROM nonelectronicitem";
		ResultSet rs = con.executeQuery(query);
		
		try {
			while(rs.next()) {
				itemID = rs.getString(1);
				itemName= rs.getString(2);
				weight = rs.getInt(3);
				fragile = rs.getInt(4);
				items.add(new NonElectronicItem(itemID, itemName, weight, fragile));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void createDelivery() {
		System.out.println("List Item");
		System.out.println("=============");
		int i = 1;
		for (Item item : items) {
			System.out.println("No: " + i++);
			System.out.println("Name: " + item.getItemName());
			System.out.println("ID: " + item.getItemID());
			System.out.println("Electronic: " + ((item instanceof ElectronicItem) ? "Electronic" : "Non-Electronic"));
			System.out.println("Weight: " + item.getWeight());
			System.out.println("Price: " + ((item instanceof ElectronicItem) ? (((ElectronicItem) item).price()) : (((NonElectronicItem) item).price())));
			System.out.println("Warranty: " + ((item instanceof ElectronicItem) ? (((ElectronicItem) item).getWarranty()) : "-"));
			System.out.println("Fragile: " + ((item instanceof NonElectronicItem) ? (((NonElectronicItem) item).getFragile()) : "-"));
			System.out.println("==============================================");
		}
		System.out.println();
		
		int choose = 0;
		String recipientName = "";
		String recipientAddress = "";
		String email = "";
		Boolean valid = true;
		
		do {
			valid = true;
			
			System.out.print("Choose Item [1 -" + items.size() + "]: ");
			choose = scan.nextInt();
			scan.nextLine();
			
			if(choose <= 0 || choose > items.size()) {
				valid = false;
			}
		} while (valid == false);
		
		do {
			valid = true;
			
			System.out.print("Input Recipient Name [5 - 10] (Inclusive): ");
			recipientName = scan.nextLine();
			if(recipientName.length() < 5 || recipientName.length() > 10) {
				valid = false;
			}
		} while (valid == false);
		
		do {
			valid = true;
			
			System.out.print("Input Recipient Address [8 - 25] (Inclusive): ");
			recipientAddress = scan.nextLine();
			
			if(recipientAddress.length() < 8 || recipientAddress.length() > 25) {
				valid = false;
			}
		} while (valid == false);
		
		do {
			valid = true;
			
			System.out.print("Input an email [must ends with '@gmail.com']: ");
			email = scan.nextLine();
			
			if(!email.endsWith("@gmail.com")) {
				valid = false;
			}
		} while (valid == false);
		
		System.out.print("[Press Enter to Continue]");
		scan.nextLine();
		
		String query = String.format("INSERT INTO package VALUES ('%s', '%s', '%s', '%s', '%s')", generatePackageID(), items.get(choose-1).getItemID(), recipientName, recipientAddress, email);
		con.executeUpdate(query);
//		System.out.println("Detail Package");
//		System.out.println("Recepient: " + recipientName);
//		System.out.println("Name: " + items.get(choose).getItemName());
//		if(items.get(choose).getItemID().startsWith("EI")) {
//			System.out.println((((ElectronicItem) items).get(choose).getWarranty()));
//		}
	}
	
	public String generatePackageID() {
		String query = "SELECT * FROM package ORDER BY packageID DESC LIMIT 1";
		ResultSet rs = con.executeQuery(query);
		String id = "";
		
		try {
			while(rs.next()) {
				id = rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String newID = id.substring(2, (id.length()-1));
		int IDnew = Integer.parseInt(newID);
		
		if(IDnew < 10) {
			newID = "PI00" + (IDnew + 1);
		}
		else if(IDnew >= 10 && IDnew < 100) {
			newID = "PI0" + (IDnew + 1);
		}
		else if(IDnew >= 100) {
			newID = "PI" + (IDnew + 1);
		}
		return newID;
	}
	
	public void viewDelivery() {
		System.out.println("All Package List");
		int i = 1;
		for (Package pack : packages) {
			System.out.println("No: " + i++);
			System.out.println("ID: " + pack.getPackageID());
			for (int j = 0; j < items.size(); j++) {
				if(pack.getItemID().equals(items.get(j).getItemID())) {
					System.out.println("Name: " + items.get(j).getItemName());
					System.out.println("Weight: " + items.get(j).getWeight());
					break;
				}
			}
			System.out.println("Recipient Name: " + pack.getRecipientName());
			System.out.println("Recipient Address: " + pack.getRecipientAddress());
			System.out.println("Email: " + pack.getUserEmail());
			System.out.println("===========================================================");
		}
		
	}
	
	public void deleteDelivery() {
		viewDelivery();
		int choose = 0;
		int temp = 0;
		
		do {
			System.out.print("Input Number To Delete (1 - " + packages.size() + "): ");
			choose = scan.nextInt();
			scan.nextLine();
		} while (choose < 1 || choose > packages.size());
		
		for(int i = 0; i < packages.size(); i++) {
			if(packages.get(choose).getPackageID().equals(packages.get(i).getPackageID())) {
				temp = i;
				break;
			}
		}
		
		String query = String.format("DELETE FROM package WHERE packageID = '%s'", packages.get(temp).getPackageID());
		con.executeUpdate(query);
	}
	
	public static void main(String[] args) {
		new Main();
	}

}

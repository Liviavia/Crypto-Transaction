
public abstract class Item {
	private String itemID;
	private String itemName;
	private int weight;
	
	public Item(String itemID, String itemName, int weight) {
		super();
		this.itemID = itemID;
		this.itemName = itemName;
		this.weight = weight;
	}
	
	public String getItemID() {
		return itemID;
	}
	public void setItemID(String itemID) {
		this.itemID = itemID;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	
	public abstract int price();
}

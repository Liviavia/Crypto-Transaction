
public class NonElectronicItem extends Item{
	private int fragile;
	
	public NonElectronicItem(String itemID, String itemName, int weight, int fragile) {
		super(itemID, itemName, weight);
		this.fragile = fragile;
	}

	public int getFragile() {
		return fragile;
	}

	public void setFragile(int fragile) {
		this.fragile = fragile;
	}

	@Override
	public int price() {
		// TODO Auto-generated method stub
		int price = 10000 * Math.round(this.getWeight());
		return price;
	}
	
	
}

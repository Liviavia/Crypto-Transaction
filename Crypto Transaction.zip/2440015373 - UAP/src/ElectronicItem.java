
public class ElectronicItem extends Item{
	private int warranty;

	public ElectronicItem(String itemID, String itemName, int weight, int warranty) {
		super(itemID, itemName, weight);
		this.warranty = warranty;
	}

	public int getWarranty() {
		return warranty;
	}

	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}

	@Override
	public int price() {
		int price = 15000 * Math.round(this.getWeight());
		return price;
	}
	
	
}
